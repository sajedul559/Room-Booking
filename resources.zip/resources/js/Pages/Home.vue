<template>
    <div>
        <h1>Welcome to Inertia with Vue.js</h1>
        <p>This is an example page.</p>
    </div>
</template>

<script>
export default {
    name: 'Home',
};
</script>

<style>
/* Optional: Add your styles here */
</style>
