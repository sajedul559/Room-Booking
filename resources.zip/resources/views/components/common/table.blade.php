<table id="example" class="table table-bordered dt-responsive nowrap table-striped align-middle"
style="width:100%">
{{ $slot }}
</table>