<!-- Loader -->
<div class="page-loader">
	<div class="page-loader-inner">
	<img src="{{ asset('assets/frontend/img/icons/loader.png') }}" alt="Loader">
	
	<label><i class="fa-solid fa-circle"></i></label>
	<label><i class="fa-solid fa-circle"></i></label>
	<label><i class="fa-solid fa-circle"></i></label>
    </div>
</div>
<!-- /Loader -->