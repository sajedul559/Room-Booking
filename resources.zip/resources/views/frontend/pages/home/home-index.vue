<template>
    <loader-index></loader-index>
    
    <layouts-header></layouts-header>

    <home-banner></home-banner>

    <index-property-type></index-property-type>

    <index-feature-property></index-feature-property>

    <index-cities-list></index-cities-list>

    <index-feature-rent></index-feature-rent>

    <index-main-property></index-main-property>

    <testimonial-index></testimonial-index>

    <faq-index></faq-index>

    <layouts-footer></layouts-footer>
</template>