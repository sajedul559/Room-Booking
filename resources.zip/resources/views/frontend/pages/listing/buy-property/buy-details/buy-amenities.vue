<template>
  <div class="collapse-card">
    <h4 class="card-title">
      <a
        class="collapsed"
        data-bs-toggle="collapse"
        href="#amenities"
        aria-expanded="false"
        >Amenities</a
      >
    </h4>
    <div id="amenities" class="card-collapse collapse show collapse-view">
      <div class="row">
        <div class="col-md-4">
          <ul class="amenities-list">
            <li>
              <img src="@/assets/img/icons/amenities-icon-1.svg" alt="Image" />Air
              Conditioning
            </li>
            <li>
              <img
                src="@/assets/img/icons/amenities-icon-2.svg"
                alt="Image"
              />Swimming Pools
            </li>
            <li>
              <img
                src="@/assets/img/icons/amenities-icon-3.svg"
                alt="Image"
              />Sporting Facilities
            </li>
            <li>
              <img src="@/assets/img/icons/amenities-icon-4.svg" alt="Image" />Gym
            </li>
            <li>
              <img
                src="@/assets/img/icons/amenities-icon-5.svg"
                alt="Image"
              />Clubhouse
            </li>
          </ul>
        </div>
        <div class="col-md-4">
          <ul class="amenities-list">
            <li>
              <img
                src="@/assets/img/icons/amenities-icon-6.svg"
                alt="Image"
              />Landscaped Gardens
            </li>
            <li>
              <img
                src="@/assets/img/icons/amenities-icon-7.svg"
                alt="Image"
              />Wide-Open Spaces
            </li>
            <li>
              <img
                src="@/assets/img/icons/amenities-icon-8.svg"
                alt="Image"
              />Parks
            </li>
            <li>
              <img
                src="@/assets/img/icons/amenities-icon-9.svg"
                alt="Image"
              />Package Lockers
            </li>
            <li>
              <img
                src="@/assets/img/icons/amenities-icon-10.svg"
                alt="Image"
              />Spa
            </li>
          </ul>
        </div>
        <div class="col-md-4">
          <ul class="amenities-list">
            <li>
              <img
                src="@/assets/img/icons/amenities-icon-11.svg"
                alt="Image"
              />Surveillance Cameras
            </li>
            <li>
              <img
                src="@/assets/img/icons/amenities-icon-12.svg"
                alt="Image"
              />Billiards Table
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
