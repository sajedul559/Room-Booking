<link href="{{ asset('assets/nice-select/css/nice-select.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ asset('assets/multiselect/css/jquery.multiselect.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ asset('assets/multiselect/css/custom_style.css') }}" rel="stylesheet" type="text/css" />

<link href="{{ asset('assets/libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet"
    type="text/css" />
<link href="{{ asset('assets/libs/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css') }}" rel="stylesheet"
    type="text/css" />
<link href="{{ asset('assets/libs/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css') }}" rel="stylesheet"
    type="text/css" />
<link href="{{ asset('assets/libs/dropzone/min/dropzone.min.css')}}" rel="stylesheet" type="text/css" />

<link href="{{ asset('assets/libs/dropify/css/dropify.min.css')}}" rel="stylesheet" type="text/css" />
<!-- Plugins css -->
<link href="{{ asset('assets/libs/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('assets/libs/flatpickr/flatpickr.min.css') }}" rel="stylesheet" type="text/css" />
<!-- Bootstrap css -->
<link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
<!-- App css -->
<link href="{{ asset('assets/css/app.min.css') }}" rel="stylesheet" type="text/css" id="app-style" />
<link href="{{ asset('assets/css/custom.css') }}" rel="stylesheet" type="text/css" id="app-style" />

<!-- icons -->
<link href="{{ asset('assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
<!-- Head js -->
<link rel="stylesheet" href="{{ asset('assets/css/toastr.min.css') }}">

