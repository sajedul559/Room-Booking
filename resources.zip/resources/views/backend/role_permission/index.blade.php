<x-admin.layouts.app :title="getbreadcumb()">
    <x-admin.partials.datatable :dataTable="$dataTable"></x-admin.partials.datatable>
</x-admin.layouts.app>
