<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\OPD\\Providers\\OPDServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\OPD\\Providers\\OPDServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);