<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Pharmacy\\Providers\\PharmacyServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Pharmacy\\Providers\\PharmacyServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);