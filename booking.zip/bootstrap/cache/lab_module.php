<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Lab\\Providers\\LabServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Lab\\Providers\\LabServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);