<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Radiology\\Providers\\RadiologyServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Radiology\\Providers\\RadiologyServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);