<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\IPD\\Providers\\IPDServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\IPD\\Providers\\IPDServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);