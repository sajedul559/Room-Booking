<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Appoinment\\Providers\\AppoinmentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Appoinment\\Providers\\AppoinmentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);