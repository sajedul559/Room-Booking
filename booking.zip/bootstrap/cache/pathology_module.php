<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Pathology\\Providers\\PathologyServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Pathology\\Providers\\PathologyServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);