<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Hospital\\Providers\\HospitalServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Hospital\\Providers\\HospitalServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);