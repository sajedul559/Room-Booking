<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Billing\\Providers\\BillingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Billing\\Providers\\BillingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);