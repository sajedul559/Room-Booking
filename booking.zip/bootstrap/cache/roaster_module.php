<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Roaster\\Providers\\RoasterServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Roaster\\Providers\\RoasterServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);