<template>
  <div class="collapse-card">
    <h4 class="card-title">
      <a
        class="collapsed"
        data-bs-toggle="collapse"
        href="#about"
        aria-expanded="false"
        >Description</a
      >
    </h4>
    <div id="about" class="card-collapse collapse show">
      <div class="about-agent collapse-view">
        <p>
          Good road frontage on a paved county road with utilities make it an
          amazing setting for your dream country getaway! If you like views, you
          must see this property!,
        </p>
        <p>
          This property is mostly wooded and sits high on a hilltop overlooking
          the Mohawk River Valley. Located right in the heart of Upstate NYs
          Amish farm Country, this land is certified organic making it extremely
          rare! Good road frontage on a paved county road with utilities make it
          an amazing setting for your dream country getaway! If you like views,
          you must see this property!This property is mostly wooded and sits
          high on a hilltop overlooking the Mohawk River Valley. Located right
          in the heart of Upstate NYs Amish farm Country, this land is certified
          organic making it extremely rare! Good road frontage on a paved county
          road with utilities make it an amazing setting for your dream country
          getaway! If you like views, you must see this property!
        </p>
      </div>
    </div>
  </div>
</template>
