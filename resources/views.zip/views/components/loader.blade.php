<!-- Loader -->
<div class="page-loader">
	<div class="page-loader-inner">
	<img src="{{URL::asset('/frontend/img/icons/loader.svg')}}" alt="Loader">
	<label><i class="fa-solid fa-circle"></i></label>
	<label><i class="fa-solid fa-circle"></i></label>
	<label><i class="fa-solid fa-circle"></i></label>
    </div>
</div>
<!-- /Loader -->