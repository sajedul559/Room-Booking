<!-- Modal -->
<div class="modal fade modal-succeess" id="success" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <div class="success-popup">
                    <h4><img src="{{URL::asset('/frontend/img/icons/double-tick.svg')}}" alt="img"></h4>
                    <h5>Payment Successful</h5>
                    <p>You Payment has been successfully done.Trasaction Id : #5064164454</p>
                    <a href="{{url('index')}}" class="btn btn-primary w-100">Back to Home</a>
                </div>
            </div>
        </div>
    </div>
</div>