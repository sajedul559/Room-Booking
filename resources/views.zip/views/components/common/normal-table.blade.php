<table id="example" class="table" style="width:100%">
{{ $slot }}
</table>