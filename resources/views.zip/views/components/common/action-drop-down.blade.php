

<div class="btn-group dropdown">
    <a href="javascript: void(0);" class="table-action-btn dropdown-toggle arrow-none btn btn-light btn-xs" data-bs-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-dots-horizontal"></i></a>
    <div class="dropdown-menu dropdown-menu-end">
        {{ $slot }}
       
    </div>
</div>